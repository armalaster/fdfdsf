﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Podgotovka.DB;

namespace Podgotovka
{
    public partial class MenegerBook : Page
    {
        public MagazinBookEntities Connect = new MagazinBookEntities();
        public ObservableCollection<Book> Books { get; set; }
        public Book AddBook { get; set; }
        public MenegerBook()
        {
            InitializeComponent();

            AddBook = new Book();
            BookList.IsEnabled = true;
            Books = new ObservableCollection<Book>(Connect.Books.ToList());
            DataContext = this;
        }

        /*private void ClearTextBox()
        {
            TextNameBook.Clear();
            TextAvtorBook.Clear();
            TextIzdatelBook.Clear();
            TextPriceBook.Clear();
            TextCostBook.Clear();
        }*/

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Connect.Books.Add(AddBook);
            int result = Connect.SaveChanges();
            
            if (result != 0)
            {
                Connect.Books.Add(AddBook);
                AddBook = new Book();
                Books = new ObservableCollection<Book>(Connect.Books.ToList());
                BookList.ItemsSource = Books;
                
                MessageBox.Show("Книга добавлена");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Хотите удалить?","Удалить", 
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Connect.Books.Remove(Books[BookList.SelectedIndex]);
                Connect.SaveChanges();
                Books = new ObservableCollection<Book>(Connect.Books.ToList());
                BookList.ItemsSource = Books;
            }
        }

        public void Search(string substring)
        {
            ICollectionView nb = CollectionViewSource.GetDefaultView(BookList.ItemsSource);
            if (nb == null) return;
            int nbcounter = 0;
            nb.Filter = new System.Predicate<Object>(obj =>
            {
                bool isnb = ((Book)obj).NameBook.ToLower().Contains(substring.ToLower());
                if(isnb) nbcounter++;
                return isnb;
            });
        } 

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Search(TextBox.Text);
        }

        private void UpDateUser(object sender, RoutedEventArgs e)
        {
            Connect.SaveChanges();
            MessageBox.Show("Обновлено");
            addB.Click -= UpDateUser;
            addB.Click += Button_Click_1;
            addB.Content = "Добавить";
            BookList.SelectedIndex = -1;
        }
        private void UpdateBindingBook()
        {
            TextNameBook.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
            TextAvtorBook.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
            TextIzdatelBook.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
            TextPriceBook.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
            TextCostBook.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
            
        }
        private void BookList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (BookList.SelectedIndex != -1)
            {
                
                addB.Click -= Button_Click_1;
                addB.Click += UpDateUser;
                addB.Content = "Обновить";
                AddBook = BookList.SelectedItem as Book;
                UpdateBindingBook();

            }
            
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
